# The Pack — website starter

A responsive, static website starter for The Pack.

## Files
- `index.html` — public homepage and informational sections
- `constitution.html` — working Constitution draft
- `styles.css` — responsive black-and-white visual system
- `script.js` — accessible mobile navigation

## Preview locally
Open `index.html` in a browser.

## Deploy to Cloudflare Pages
1. Create a GitHub repository and upload these files to its root.
2. In Cloudflare, open Workers & Pages and create a Pages project.
3. Connect the GitHub repository.
4. For a plain static site, leave the build command empty and set the output directory to `/`.
5. Deploy and test the resulting `pages.dev` address.

## Important status notes
This is a starter prototype, not a legally reviewed or formally approved organisation website. The Constitution is explicitly labelled a working draft. Membership applications, payments, member accounts and expedition sign-ups are intentionally not implemented. Do not add them until governance, adult oversight, safeguarding, privacy and legal arrangements are ready.

## Customisation
- Update the Instagram URL in `index.html` if the account handle changes.
- Replace the inline fox mark with the approved final logo artwork if desired.
- Review every Constitution article with the founding group before ratification.
